# Deteksi Plat Nomor Mobil > 2024-10-31 2:31pm
https://universe.roboflow.com/unm-co30r/deteksi-plat-nomor-mobil-acah9-ernyr

Provided by a Roboflow user
License: CC BY 4.0

